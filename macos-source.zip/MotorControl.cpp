#include "Rs485.h"
#include "Turntable.h"

#include <QApplication>
#include <QCheckBox>
#include <QCloseEvent>
#include <QComboBox>
#include <QDateTime>
#include <QDialog>
#include <QDialogButtonBox>
#include <QDir>
#include <QDoubleSpinBox>
#include <QElapsedTimer>
#include <QFile>
#include <QFileInfo>
#include <QFontDatabase>
#include <QGridLayout>
#include <QGroupBox>
#include <QHBoxLayout>
#include <QIcon>
#include <QLabel>
#include <QLineEdit>
#include <QPainter>
#include <QPlainTextEdit>
#include <QPushButton>
#include <QResizeEvent>
#include <QSaveFile>
#include <QSerialPortInfo>
#include <QSpinBox>
#include <QStandardPaths>
#include <QTimer>
#include <QVBoxLayout>

#include <algorithm>
#include <array>
#include <cmath>
#include <functional>

namespace
{
constexpr int replyTimeoutMs = 500;
constexpr double pi = 3.14159265358979323846;
const std::array<const char*, 6> stationColors{
    "#d64040", "#3aa05c", "#3a74d6", "#eec840", "#925cc2", "#808080"};

QString Hex(const lk::Bytes& bytes)
{
    return QString::fromLatin1(QByteArray(reinterpret_cast<const char*>(bytes.data()),
        static_cast<int>(bytes.size())).toHex(' ').toUpper());
}

class StationDial : public QWidget
{
public:
    explicit StationDial(QWidget* parent = nullptr) : QWidget(parent)
    {
        setMinimumSize(330, 330);
        for (int i = 0; i < 6; ++i)
        {
            buttons[i] = new QPushButton(QStringLiteral("%1\n%2°").arg(i + 1).arg(i * 60), this);
            buttons[i]->setFixedSize(66, 66);
            buttons[i]->setStyleSheet(QStringLiteral(
                "QPushButton { background:%1; color:%2; border:2px solid #666; border-radius:33px; font-weight:600; }"
                "QPushButton:hover { border-color:white; }"
                "QPushButton:disabled { background:#414141; color:#888; border-color:#555; }"
                "QPushButton[selected=\"true\"] { background:%1; color:%2; border:3px solid white; }")
                .arg(QString::fromLatin1(stationColors[i]), i == 3 ? QStringLiteral("#242424") : QStringLiteral("white")));
        }
    }

    void Mark(int station = -1)
    {
        selected_ = station;
        for (int i = 0; i < 6; ++i)
        {
            const bool selected = station == i;
            if (buttons[i]->property("selected").toBool() == selected) continue;
            buttons[i]->setProperty("selected", selected);
            // Reapply the sheet so the selected color also appears on disabled buttons.
            buttons[i]->setStyleSheet(buttons[i]->styleSheet());
        }
        update();
    }

    std::array<QPushButton*, 6> buttons;

protected:
    void resizeEvent(QResizeEvent*) override
    {
        const QPointF center(width() / 2.0, height() / 2.0);
        const double radius = std::min(width(), height()) / 2.0 - 48;
        for (int i = 0; i < 6; ++i)
        {
            const double angle = -pi / 2 + i * pi / 3;
            buttons[i]->move(qRound(center.x() + radius * std::cos(angle)) - 33,
                qRound(center.y() + radius * std::sin(angle)) - 33);
        }
    }

    void paintEvent(QPaintEvent*) override
    {
        QPainter painter(this);
        painter.setRenderHint(QPainter::Antialiasing);
        const QPointF center(width() / 2.0, height() / 2.0);
        const double radius = std::min(width(), height()) / 2.0 - 48;
        painter.setPen(QPen(QColor("#555555"), 2));
        painter.drawEllipse(center, radius, radius);
        if (selected_ >= 0)
        {
            painter.setPen(QPen(Qt::white, 3));
            painter.drawEllipse(buttons[selected_]->geometry().adjusted(-4, -4, 4, 4));
        }
        painter.setPen(QColor("#dddddd"));
        painter.drawText(rect(), Qt::AlignCenter, QStringLiteral("转盘"));
    }

private:
    int selected_ = -1;
};

enum class Operation { Idle, Connecting, Preparing, Moving, Jogging, SetOrigin, Clearing, Stopping, Diagnostics };
enum class CloseTarget { None, Port, Window };

struct Pending
{
    lk::Byte command;
    std::size_t length;
    qint64 deadline;
    std::function<void(const lk::Frame&)> callback;
};

struct MoveState
{
    int station = 0;
    std::int64_t target = 0;
    std::int64_t travel = 0;
    std::uint32_t speed = 0;
    bool timed = false;
    bool absolute = true;
    bool release = false;
    int stableSamples = 0;
    qint64 startedAt = 0;
    qint64 deadline = 0;
    qint64 earliestFinish = 0;
    qint64 nextProgressLog = 0;
};

class MotorControlWindow : public QWidget
{
public:
    MotorControlWindow()
    {
        setWindowTitle(QStringLiteral("转盘控制"));
        resize(850, 680);
        setMinimumSize(790, 640);
        setStyleSheet(QStringLiteral(
            "QWidget { background:#202020; color:#ebebeb; }"
            "QGroupBox { border:1px solid #4b4b4b; margin-top:8px; border-radius:4px; }"
            "QGroupBox::title { subcontrol-origin:margin; left:10px; padding:0 4px; }"
            "QPushButton { background:#363636; border:1px solid #606060; border-radius:4px; padding:5px 10px; min-height:22px; }"
            "QPushButton:hover { background:#454545; border-color:#aaa; }"
            "QPushButton:pressed { background:#292929; }"
            "QPushButton:disabled { color:#888; border-color:#444; }"
            "QPushButton#stop { background:#ac2935; border-color:#ac2935; color:white; }"
            "QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit { background:#2d2d2d; border:1px solid #626262; border-radius:3px; padding:4px; min-height:22px; }"
            "QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled, QLineEdit:disabled { color:#888; border-color:#444; }"
            "QPlainTextEdit { background:#191919; border:1px solid #484848; padding:5px; }"
            "QCheckBox { spacing:6px; }"));

        auto* layout = new QVBoxLayout(this);
        layout->setContentsMargins(16, 14, 16, 14);
        layout->setSpacing(12);
        auto* connection = new QHBoxLayout;
        com_ = new QComboBox;
        com_->setEditable(true);
        com_->setMinimumWidth(110);
        refresh_ = new QPushButton(QStringLiteral("刷新"));
        baud_ = new QComboBox;
        for (const int rate : {9600, 19200, 38400, 57600, 115200, 230400, 460800, 921600})
            baud_->addItem(QString::number(rate), rate);
        baud_->setCurrentIndex(4);
        open_ = new QPushButton(QStringLiteral("打开串口"));
        connectionState_ = new QLabel(QStringLiteral("未连接"));
        connection->addWidget(new QLabel(QStringLiteral("串口")));
        connection->addWidget(com_);
        connection->addWidget(refresh_);
        connection->addSpacing(8);
        connection->addWidget(new QLabel(QStringLiteral("波特率")));
        connection->addWidget(baud_);
        connection->addWidget(open_);
        connection->addWidget(connectionState_, 1);
        layout->addLayout(connection);

        auto* parameters = new QHBoxLayout;
        speed_ = new QDoubleSpinBox;
        speed_->setRange(0.01, 6000);
        speed_->setDecimals(2);
        speed_->setValue(600);
        speed_->setSuffix(QStringLiteral(" °/s"));
        tolerance_ = new QDoubleSpinBox;
        tolerance_->setRange(0.01, 5);
        tolerance_->setDecimals(2);
        tolerance_->setValue(1.0);
        tolerance_->setSuffix(QStringLiteral("°"));
        ratio_ = new QDoubleSpinBox;
        ratio_->setRange(0.01, 100);
        ratio_->setDecimals(2);
        ratio_->setValue(1);
        ratio_->setToolTip(QStringLiteral("电机转角÷轮盘转角。例如填10表示电机转10圈，轮盘转1圈；直驱填1。"));
        mode_ = new QComboBox;
        mode_->addItems({QStringLiteral("绝对定位（单圈）"), QStringLiteral("增量定位（差值）")});
        parameters->setSpacing(18);
        const auto addParameter = [parameters](const QString& text, QDoubleSpinBox* editor) {
            auto* group = new QHBoxLayout;
            group->setSpacing(6);
            auto* label = new QLabel(text);
            label->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
            group->addWidget(label);
            group->addWidget(editor);
            parameters->addLayout(group);
            parameters->addStretch(1);
        };
        addParameter(QStringLiteral("速度"), speed_);
        addParameter(QStringLiteral("容差"), tolerance_);
        addParameter(QStringLiteral("传动比"), ratio_);
        parameters->addWidget(mode_);
        layout->addLayout(parameters);

        auto* middle = new QHBoxLayout;
        middle->setSpacing(16);
        dial_ = new StationDial;
        middle->addWidget(dial_, 1);
        auto* right = new QVBoxLayout;
        angle_ = new QLabel(QStringLiteral("角度：--"));
        auto angleFont = angle_->font();
        angleFont.setPointSize(16);
        angle_->setFont(angleFont);
        origin_ = new QPushButton(QStringLiteral("设当前为1号位"));
        debug_ = new QPushButton(QStringLiteral("调试设置"));
        auto* angleRow = new QHBoxLayout;
        angleRow->addWidget(angle_, 1);
        angleRow->addWidget(debug_);
        right->addLayout(angleRow);
        diagnose_ = new QPushButton(QStringLiteral("读取多圈角度与限制"));
        diagnose_->setToolTip(QStringLiteral("读取累计角度、Max Angle 和驱动器状态，用于排查连续正转后无法定位。"));
        right->addWidget(diagnose_);
        station_ = new QLabel(QStringLiteral("当前工位：--"));
        right->addWidget(station_);
        log_ = new QPlainTextEdit;
        log_->setReadOnly(true);
        log_->setMaximumBlockCount(1000);
        log_->setFont(QFontDatabase::systemFont(QFontDatabase::FixedFont));
        right->addWidget(log_, 1);
        middle->addLayout(right, 1);
        layout->addLayout(middle, 1);

        auto* tools = new QHBoxLayout;
        jogStep_ = new QDoubleSpinBox;
        jogStep_->setRange(0.01, 180);
        jogStep_->setDecimals(2);
        jogStep_->setValue(0.5);
        jogStep_->setSuffix(QStringLiteral("°"));
        jogLeft_ = new QPushButton(QStringLiteral("◀ 点动"));
        jogRight_ = new QPushButton(QStringLiteral("点动 ▶"));
        jogStep_->setToolTip(QStringLiteral("点动输出速度为40°/s，电机速度按传动比换算。"));
        tools->addWidget(new QLabel(QStringLiteral("点动步长")));
        tools->addWidget(jogStep_);
        tools->addWidget(jogLeft_);
        tools->addWidget(jogRight_);
        tools->addWidget(origin_);
        layout->addLayout(tools);

        auto* sequenceBox = new QGroupBox(QStringLiteral("序列"));
        auto* sequenceLayout = new QGridLayout(sequenceBox);
        sequenceText_ = new QLineEdit(QStringLiteral("1:500, 3:500, 5:500"));
        sequenceText_->setToolTip(QStringLiteral("工位:停留毫秒，用逗号分隔。"));
        loop_ = new QCheckBox(QStringLiteral("循环"));
        loop_->setChecked(true);
        run_ = new QPushButton(QStringLiteral("运行序列"));
        stop_ = new QPushButton(QStringLiteral("停止"));
        stop_->setObjectName(QStringLiteral("stop"));
        sequenceLayout->addWidget(sequenceText_, 0, 0, 1, 4);
        sequenceLayout->addWidget(loop_, 0, 4);
        sequenceLayout->addWidget(run_, 0, 5);
        sequenceLayout->addWidget(stop_, 0, 6);
        home_ = new QPushButton(QStringLiteral("复位到1号位"));
        moveMargin_ = new QSpinBox;
        moveMargin_->setRange(0, 60000);
        moveMargin_->setValue(60);
        moveMargin_->setSuffix(QStringLiteral(" ms"));
        moveMargin_->setToolTip(QStringLiteral("按时间推进时，在估算运动时间之外增加的等待时间；序列文本里的时间是之后的工位停留时间。"));
        forward_ = new QCheckBox(QStringLiteral("单向正转"));
        forward_->setChecked(true);
        sequenceLayout->addWidget(home_, 1, 0, 1, 2);
        auto* marginGroup = new QHBoxLayout;
        marginGroup->setSpacing(6);
        auto* marginLabel = new QLabel(QStringLiteral("运动余量"));
        marginLabel->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Preferred);
        marginGroup->addWidget(marginLabel);
        marginGroup->addWidget(moveMargin_);
        sequenceLayout->addLayout(marginGroup, 1, 2, 1, 2);
        sequenceLayout->addWidget(forward_, 1, 4, 1, 3);
        layout->addWidget(sequenceBox);

        for (int i = 0; i < 6; ++i)
            connect(dial_->buttons[i], &QPushButton::clicked, this, [this, i] {
                Guard([this, i] { StartMove(i, false); });
            });
        connect(refresh_, &QPushButton::clicked, this, [this] { RefreshPorts(); });
        connect(open_, &QPushButton::clicked, this, [this] { Guard([this] { TogglePort(); }); });
        connect(origin_, &QPushButton::clicked, this, [this] { Guard([this] { SetOrigin(); }); });
        connect(jogLeft_, &QPushButton::clicked, this, [this] { Guard([this] { Jog(-1); }); });
        connect(jogRight_, &QPushButton::clicked, this, [this] { Guard([this] { Jog(1); }); });
        connect(debug_, &QPushButton::clicked, this, [this] { Guard([this] { OpenDebugSettings(); }); });
        connect(diagnose_, &QPushButton::clicked, this, [this] { Guard([this] {
            if (Ready()) ReadDiagnostics();
        }); });
        connect(run_, &QPushButton::clicked, this, [this] { Guard([this] { StartSequence(); }); });
        connect(stop_, &QPushButton::clicked, this, [this] {
            homePending_ = false;
            Guard([this] { Stop(); });
        });
        connect(home_, &QPushButton::clicked, this, [this] { Guard([this] { Home(); }); });
        connect(mode_, static_cast<void(QComboBox::*)(int)>(&QComboBox::currentIndexChanged),
            this, [this] { UpdateControls(); });
        connect(&timer_, &QTimer::timeout, this, [this] { Guard([this] { Tick(); }); });
        clock_.start();
        InitFiles();
        LoadOrigin();
        RefreshPorts();
        timer_.start(15);
        UpdateControls();
    }

protected:
    void closeEvent(QCloseEvent* event) override
    {
        if (!port_.IsOpen()) { event->accept(); return; }
        event->ignore();
        Guard([this] { RequestClose(CloseTarget::Window); });
    }

private:
    template<class Action>
    void Guard(Action action)
    {
        try { action(); }
        catch (const std::wstring& message)
        {
            const bool moving = operation_ == Operation::Moving || operation_ == Operation::Preparing;
            Log(QString::fromStdWString(message));
            ClearPending();
            sequenceRunning_ = false;
            homePending_ = false;
            const auto closing = closeTarget_;
            if (closing != CloseTarget::None)
            {
                Log(QStringLiteral("停止未确认，正在释放串口。"));
                CompleteClose(closing);
            }
            else
            {
                confirmed_ = false;
                if (moving && port_.IsOpen())
                {
                    Log(QStringLiteral("运动操作失败，自动发送停止命令。"));
                    diagnoseAfterStop_ = true;
                    try
                    {
                        Stop();
                        return;
                    }
                    catch (const std::wstring& stopError)
                    {
                        ClearPending();
                        Log(QStringLiteral("停止发送失败：%1").arg(QString::fromStdWString(stopError)));
                    }
                }
                diagnoseAfterStop_ = false;
                operation_ = Operation::Idle;
                Log(QStringLiteral("本次操作已中断，可发送停止或关闭串口。"));
                UpdateControls();
            }
        }
    }

    void InitFiles()
    {
        const QString folder = QStandardPaths::writableLocation(QStandardPaths::AppLocalDataLocation);
        configPath_ = QDir(folder).filePath(QStringLiteral("Turntable.cfg"));
        const QString logs = QDir(folder).filePath(QStringLiteral("logs"));
        QDir().mkpath(logs);
        logFile_.setFileName(QDir(logs).filePath(QStringLiteral("six-station-%1-%2.log")
            .arg(QDateTime::currentDateTime().toString(QStringLiteral("yyyyMMdd-HHmmss-zzz")))
            .arg(QApplication::applicationPid())));
        if (logFile_.open(QIODevice::WriteOnly | QIODevice::Text))
            Log(QStringLiteral("通信日志：%1").arg(QDir::toNativeSeparators(logFile_.fileName())));
        else
            Log(QStringLiteral("日志文件创建失败：%1").arg(logFile_.errorString()));
        Log(QStringLiteral("六工位正转版，参考转盘1351；电机 ID 1。"));
        Log(QStringLiteral("程序：%1；文件时间：%2。")
            .arg(QDir::toNativeSeparators(QApplication::applicationFilePath()))
            .arg(QFileInfo(QApplication::applicationFilePath()).lastModified().toString(Qt::ISODate)));
    }

    void LoadOrigin()
    {
        QString path = configPath_;
        if (!QFile::exists(path))
            path = QDir(QApplication::applicationDirPath()).filePath(QStringLiteral("Turntable.cfg"));
        QFile file(path);
        if (!file.exists()) return;
        if (!file.open(QIODevice::ReadOnly))
        {
            Log(QStringLiteral("参考位置读取失败：%1").arg(file.errorString()));
            return;
        }
        for (const auto& line : file.readAll().split('\n'))
        {
            if (!line.trimmed().startsWith("offset=")) continue;
            bool ok = false;
            const double offset = line.trimmed().mid(7).toDouble(&ok);
            if (ok && std::isfinite(offset) && std::abs(offset) < 1.0e12)
            {
                offset_ = std::llround(offset);
                Log(QStringLiteral("已加载1号位参考角度 %1°。").arg(offset_ / 100.0, 0, 'f', 2));
            }
        }
    }

    void RefreshPorts()
    {
        const QString previous = com_->currentText();
        com_->clear();
        for (const auto& info : QSerialPortInfo::availablePorts())
            com_->addItem(info.portName());
        if (!previous.isEmpty()) com_->setEditText(previous);
    }

    void TogglePort()
    {
        if (port_.IsOpen()) { RequestClose(CloseTarget::Port); return; }
        const QString name = com_->currentText().trimmed();
        if (name.isEmpty()) throw std::wstring(L"请选择串口。");
        port_.Open(name.toStdWString(), baud_->currentData().toUInt());
        operation_ = Operation::Connecting;
        confirmed_ = false;
        reader_.Clear();
        Log(QStringLiteral("已打开 %1，%2，8N1。").arg(name).arg(baud_->currentText()));
        Request(lk::Connect, 0, {}, [this](const lk::Frame&) {
            Request(lk::MotorRun, 0, {}, [this](const lk::Frame&) {
                ReadPosition([this](std::int64_t value) {
                    UpdatePosition(value);
                    confirmed_ = true;
                    Finish(QStringLiteral("电机已应答。"));
                });
            });
        });
        UpdateControls();
    }

    void Send(lk::Byte command, const lk::Bytes& data)
    {
        const auto frame = lk::Encode(command, 1, data);
        port_.Write(frame);
        Log(QStringLiteral("TX  ") + Hex(frame), false);
    }

    void ClearPending()
    {
        hasPending_ = false;
        pending_ = Pending{};
    }

    void Request(lk::Byte command, std::size_t length, const lk::Bytes& data,
        std::function<void(const lk::Frame&)> callback)
    {
        if (hasPending_) throw std::wstring(L"已有指令等待应答。");
        Send(command, data);
        pending_ = Pending{command, length, clock_.elapsed() + replyTimeoutMs, std::move(callback)};
        hasPending_ = true;
    }

    void ReadPosition(std::function<void(std::int64_t)> callback)
    {
        const bool multiTurn = ratio_->value() != 1.0;
        Request(multiTurn ? lk::ReadAngle : lk::ReadSingleAngle, multiTurn ? 8 : 4, {},
            [this, callback, multiTurn](const lk::Frame& frame) {
            const auto value = multiTurn ? lk::DecodeAngle(frame.payload) : lk::DecodeSingleAngle(frame.payload);
            UpdatePosition(value);
            callback(value);
        });
    }

    void UpdatePosition(std::int64_t value)
    {
        position_ = value;
        hasPosition_ = true;
        double output = std::fmod((value - offset_) / 100.0 / ratio_->value(), 360.0);
        if (output < 0) output += 360.0;
        angle_->setText(QStringLiteral("角度：%1°").arg(output, 0, 'f', 2));
        int actual = -1;
        const int outputUnits = qRound(output * 100) % lk::FullTurn;
        const int limit = qRound(tolerance_->value() * 100);
        for (int i = 0; i < 6; ++i)
        {
            const int difference = turret::TravelTo(i * 6000, outputUnits, false);
            if (std::abs(difference) <= limit) { actual = i; break; }
        }
        currentStation_ = actual;
        dial_->Mark(actual);
        station_->setText(actual >= 0 ? QStringLiteral("当前工位：%1").arg(actual + 1)
            : QStringLiteral("当前工位：--"));
    }

    void SetOrigin()
    {
        if (!Ready()) return;
        operation_ = Operation::SetOrigin;
        ReadPosition([this](std::int64_t value) {
            const QString folder = QFileInfo(configPath_).absolutePath();
            if (!QDir().mkpath(folder)) throw std::wstring(L"无法创建参考位置保存目录。");
            QSaveFile file(configPath_);
            const QByteArray data = "offset=" + QByteArray::number(static_cast<qlonglong>(value)) + "\n";
            if (!file.open(QIODevice::WriteOnly) || file.write(data) != data.size() || !file.commit())
                throw std::wstring(L"参考位置保存失败。");
            offset_ = value;
            UpdatePosition(value);
            Finish(QStringLiteral("已将当前位置设为1号位并保存。"));
        });
        UpdateControls();
    }

    bool Ready() const { return port_.IsOpen() && operation_ == Operation::Idle && !hasPending_ && !sequenceRunning_; }

    void StartMove(int targetStation, bool timed)
    {
        if (!port_.IsOpen() || operation_ != Operation::Idle || hasPending_) return;
        if ((timed || mode_->currentIndex() == 0) && ratio_->value() != 1.0)
            throw std::wstring(L"单圈绝对定位使用1:1直驱。带减速机构请使用增量定位并确认实物角度。");
        operation_ = Operation::Preparing;
        move_ = {};
        move_.station = targetStation;
        move_.timed = timed;
        move_.absolute = timed || mode_->currentIndex() == 0;
        move_.release = releaseAfterArrival_ && !timed;
        move_.speed = static_cast<std::uint32_t>(qRound(speed_->value() * 100));
        Log(QStringLiteral("正在转到%1号位…").arg(targetStation + 1));
        // Check the current position before changing the driver's run state.
        ReadPosition([this](std::int64_t value) { SendMove(value); });
        UpdateControls();
    }

    void SendMove(std::int64_t current)
    {
        const bool absolute = move_.absolute;
        move_.target = absolute ? turret::AngleTo(static_cast<int>(offset_ % lk::FullTurn), move_.station)
            : turret::GearedTarget(offset_, current, move_.station, ratio_->value());
        const auto shortest = absolute
            ? turret::TravelTo(static_cast<int>(current), static_cast<int>(move_.target), false)
            : move_.target - current;
        if (std::abs(shortest) <= qRound(tolerance_->value() * ratio_->value() * 100))
        {
            if (move_.timed)
            {
                operation_ = Operation::Moving;
                move_.startedAt = clock_.elapsed();
                move_.deadline = move_.startedAt + moveMargin_->value();
                Log(QStringLiteral("当前已在目标容差内，等待运动余量后推进。"));
                UpdateControls();
                return;
            }
            CompleteMove(QStringLiteral("当前位置已在%1号位容差内。").arg(move_.station + 1));
            return;
        }

        Request(lk::MotorRun, 0, {}, [this, current](const lk::Frame&) {
            SendMotion(current);
        });
    }

    void SendMotion(std::int64_t current)
    {
        const bool absolute = move_.absolute;
        lk::Byte command = lk::MoveSingleLimited;
        lk::Bytes payload;
        if (absolute)
        {
            move_.travel = turret::TravelTo(static_cast<int>(current), static_cast<int>(move_.target), forward_->isChecked());
            payload = lk::SingleAnglePayload(static_cast<int>(move_.target), move_.travel < 0, move_.speed);
        }
        else
        {
            move_.travel = move_.target - current;
            move_.speed = static_cast<std::uint32_t>(qRound(speed_->value() * ratio_->value() * 100));
            if (move_.speed == 0 || move_.speed > 600000) throw std::wstring(L"换算后的电机速度需在0.01～6000°/s。");
            command = lk::MoveLimited;
            payload = lk::Motion{static_cast<std::int32_t>(move_.travel), move_.speed}.payload();
        }
        move_.startedAt = clock_.elapsed();
        const qint64 travelMs = (1000LL * std::abs(move_.travel) + move_.speed - 1) / move_.speed;
        move_.earliestFinish = move_.startedAt + travelMs;
        move_.deadline = move_.timed ? move_.earliestFinish + moveMargin_->value()
            : move_.startedAt + std::max<qint64>(15000, 2 * travelMs + 5000);
        operation_ = Operation::Moving;
        Log(QStringLiteral("目标单圈 %1°，方向 %2，预计转角 %3°，电机速度 %4°/s。")
            .arg(move_.target / 100.0, 0, 'f', 2)
            .arg(move_.travel >= 0 ? QStringLiteral("正") : QStringLiteral("反"))
            .arg(move_.travel / 100.0, 0, 'f', 2).arg(move_.speed / 100.0, 0, 'f', 2));
        Request(command, 7, payload, [this](const lk::Frame&) {
            nextPoll_ = clock_.elapsed() + 10;
            if (move_.timed)
            {
                hasPosition_ = false;
                position_ = 0;
                currentStation_ = -1;
                angle_->setText(QStringLiteral("角度：--"));
                dial_->Mark(move_.station);
                station_->setText(QStringLiteral("目标工位：%1（按时间推进）").arg(move_.station + 1));
                Log(QStringLiteral("按时间推进，等待%1 ms后进入停留。")
                    .arg(std::max<qint64>(0, move_.deadline - clock_.elapsed())));
            }
        });
        UpdateControls();
    }

    void PollMotion()
    {
        ReadPosition([this](std::int64_t value) {
            const auto difference = ratio_->value() == 1.0
                ? turret::TravelTo(static_cast<int>(value), static_cast<int>(move_.target), false)
                : move_.target - value;
            const bool inTolerance = std::abs(difference) <= qRound(tolerance_->value() * ratio_->value() * 100);
            move_.stableSamples = inTolerance ? move_.stableSamples + 1 : 0;
            if (clock_.elapsed() >= move_.nextProgressLog)
            {
                Log(QStringLiteral("定位反馈：目标 %1°，实际 %2°，轮盘偏差 %3°，容差 ±%4°，连续命中 %5/2。")
                    .arg(move_.target / 100.0, 0, 'f', 2).arg(value / 100.0, 0, 'f', 2)
                    .arg(difference / (100.0 * ratio_->value()), 0, 'f', 2)
                    .arg(tolerance_->value(), 0, 'f', 2).arg(move_.stableSamples), false);
                move_.nextProgressLog = clock_.elapsed() + 500;
            }
            if (inTolerance && move_.release)
            {
                move_.release = false;
                Request(lk::MotorOff, 0, {}, [this](const lk::Frame&) {
                    ReadPosition([this](std::int64_t) {
                        CompleteMove(QStringLiteral("已进入容差并关闭电机输出。"));
                    });
                });
            }
            else if (move_.stableSamples >= 2 && clock_.elapsed() >= move_.earliestFinish)
            {
                CompleteMove(QStringLiteral("运动完成，实际单圈位置 %1°，耗时 %2 ms。")
                    .arg(value / 100.0, 0, 'f', 2).arg(clock_.elapsed() - move_.startedAt));
            }
            else
                nextPoll_ = clock_.elapsed() + 10;
        });
    }

    void CompleteMove(const QString& message)
    {
        operation_ = Operation::Idle;
        Log(message);
        if (sequenceRunning_)
        {
            sequenceWaiting_ = true;
            sequenceDue_ = clock_.elapsed() + steps_[sequenceIndex_].dwellMs;
        }
        UpdateControls();
    }

    void Jog(int direction)
    {
        if (!Ready()) return;
        const int travel = qRound(direction * jogStep_->value() * ratio_->value() * 100);
        const auto speed = static_cast<std::uint32_t>(qRound(40 * ratio_->value() * 100));
        if (travel == 0 || speed > 600000)
            throw std::wstring(L"换算后的点动角度需大于0，速度需不超过6000°/s。");
        operation_ = Operation::Jogging;
        move_ = {};
        // Match Jog() in the supplied C# reference: A8, wait 300 ms, read once.
        Send(lk::MoveLimited, lk::Motion{travel, speed}.payload());
        Log(QStringLiteral("点动 %1°，电机转角 %2°，电机速度 %3°/s（0xA8）。")
            .arg(direction * jogStep_->value(), 0, 'f', 2)
            .arg(travel / 100.0, 0, 'f', 2).arg(speed / 100.0, 0, 'f', 2));
        move_.deadline = clock_.elapsed() + 300;
        UpdateControls();
    }

    void OpenDebugSettings()
    {
        QDialog dialog(this);
        dialog.setWindowTitle(QStringLiteral("调试设置"));
        dialog.setMinimumWidth(320);
        auto* layout = new QVBoxLayout(&dialog);
        layout->setContentsMargins(18, 18, 18, 18);
        layout->setSpacing(16);

        auto* timed = new QCheckBox(QStringLiteral("按时间推进"), &dialog);
        timed->setChecked(sequenceUsesTiming_);
        timed->setToolTip(QStringLiteral("自动序列按估算运动时间加运动余量推进；取消后使用位置反馈判断。"));
        layout->addWidget(timed);
        auto* release = new QCheckBox(QStringLiteral("到位后松轴"), &dialog);
        release->setChecked(releaseAfterArrival_);
        release->setToolTip(QStringLiteral("仅反馈定位模式生效；进入目标容差后关闭电机输出。"));
        layout->addWidget(release);
        auto* clearLoops = new QPushButton(QStringLiteral("清除多圈圈数"), &dialog);
        clearLoops->setToolTip(QStringLiteral("发送0x93清除累计圈数，不会转回1号位。"));
        clearLoops->setEnabled(Ready());
        layout->addWidget(clearLoops);
        auto* buttons = new QDialogButtonBox(QDialogButtonBox::Close, &dialog);
        layout->addWidget(buttons);

        connect(timed, &QCheckBox::toggled, &dialog, [this](bool checked) {
            sequenceUsesTiming_ = checked;
            UpdateControls();
        });
        connect(release, &QCheckBox::toggled, &dialog, [this](bool checked) {
            releaseAfterArrival_ = checked;
        });
        connect(clearLoops, &QPushButton::clicked, &dialog, [this, &dialog] {
            dialog.accept();
            Guard([this] { ClearLoops(); });
        });
        connect(buttons, &QDialogButtonBox::rejected, &dialog, &QDialog::reject);
        dialog.exec();
    }

    void ClearLoops()
    {
        if (!Ready()) return;
        operation_ = Operation::Clearing;
        Request(lk::ClearLoops, 0, {}, [this](const lk::Frame&) {
            ReadPosition([this](std::int64_t) { Finish(QStringLiteral("已清除多圈角度圈数（0x93）。")); });
        });
        UpdateControls();
    }

    void ReadDiagnostics()
    {
        operation_ = Operation::Diagnostics;
        Log(QStringLiteral("正在读取累计多圈角度、限制设置和驱动器状态…"));
        Request(lk::ReadAngle, 8, {}, [this](const lk::Frame& angleFrame) {
            const auto multiAngle = lk::DecodeAngle(angleFrame.payload);
            Log(QStringLiteral("驱动器累计多圈角度：%1°（约 %2 圈）。")
                .arg(multiAngle / 100.0, 0, 'f', 2).arg(multiAngle / 36000.0, 0, 'f', 3));
            Request(lk::ReadSettings, 104, {}, [this, multiAngle](const lk::Frame& settingsFrame) {
                const auto& data = settingsFrame.payload;
                const auto readU32 = [&data](int offset) {
                    std::uint32_t value = 0;
                    for (int i = 0; i < 4; ++i) value |= static_cast<std::uint32_t>(data[offset + i]) << (8 * i);
                    return value;
                };
                // Layout of saveSetting_t in the supplied LK Motor Tool V2.35.
                if (readU32(100) == 0x55AA5678)
                {
                    const lk::Bytes angleBytes(data.begin() + 80, data.begin() + 88);
                    const auto maxAngle = lk::DecodeAngle(angleBytes);
                    Log(QStringLiteral("驱动器 Max Angle：%1°；Max Speed：%2°/s；Speed Ramp：%3。")
                        .arg(maxAngle / 100.0, 0, 'f', 2)
                        .arg(readU32(72) / 100.0, 0, 'f', 2).arg(readU32(92)));
                    if (maxAngle > 0 && (multiAngle >= maxAngle - 100 || multiAngle <= -maxAngle + 100))
                        Log(QStringLiteral("累计角度已接近或达到 Max Angle，连续同向转动可能受限。"));
                }
                else
                    Log(QStringLiteral("设置数据结构与已知版本不同，请查看原始回包或用官方工具读取 Max Angle。"));
                Request(lk::ReadFault, 7, {}, [this](const lk::Frame& statusFrame) {
                    Log(QStringLiteral("驱动器状态错误标志：0x%1。")
                        .arg(statusFrame.payload[6], 2, 16, QLatin1Char('0')));
                    Finish(QStringLiteral("诊断读取完成。"));
                });
            });
        });
        UpdateControls();
    }

    void StartSequence()
    {
        if (!Ready()) return;
        steps_ = turret::ParseSequence(sequenceText_->text());
        sequenceRunning_ = true;
        sequenceWaiting_ = false;
        sequenceIndex_ = 0;
        sequenceRound_ = 1;
        Log(QStringLiteral("序列开始：%1。").arg(sequenceText_->text()));
        StartMove(steps_[0].station, sequenceUsesTiming_);
    }

    void AdvanceSequence()
    {
        sequenceWaiting_ = false;
        ++sequenceIndex_;
        if (sequenceIndex_ == steps_.size())
        {
            if (!loop_->isChecked())
            {
                sequenceRunning_ = false;
                Finish(QStringLiteral("序列结束。"));
                return;
            }
            sequenceIndex_ = 0;
            ++sequenceRound_;
            Log(QStringLiteral("第%1轮。").arg(sequenceRound_));
        }
        StartMove(steps_[sequenceIndex_].station, sequenceUsesTiming_);
    }

    void Home()
    {
        if (!port_.IsOpen()) return;
        if (operation_ == Operation::Idle && !hasPending_)
        {
            sequenceRunning_ = false;
            sequenceWaiting_ = false;
            homePending_ = false;
            StartMove(0, false);
            return;
        }
        homePending_ = true;
        Stop();
    }

    void Stop()
    {
        if (!port_.IsOpen()) return;
        sequenceRunning_ = false;
        sequenceWaiting_ = false;
        if (operation_ == Operation::Stopping && hasPending_ && pending_.command == lk::Stop) return;
        ClearPending();
        reader_.Clear();
        operation_ = Operation::Stopping;
        Log(QStringLiteral("正在发送停止命令…"));
        Request(lk::Stop, 0, {}, [this](const lk::Frame&) {
            Log(QStringLiteral("驱动器已应答停止命令。"));
            if (closeTarget_ != CloseTarget::None) { CompleteClose(closeTarget_); return; }
            if (homePending_)
            {
                operation_ = Operation::Idle;
                homePending_ = false;
                StartMove(0, false);
            }
            else if (diagnoseAfterStop_)
            {
                diagnoseAfterStop_ = false;
                ReadDiagnostics();
            }
            else
                ReadPosition([this](std::int64_t) { Finish(QStringLiteral("停止命令已应答，位置已读取。")); });
        });
        UpdateControls();
    }

    void RequestClose(CloseTarget target)
    {
        if (closeTarget_ != CloseTarget::None)
        {
            if (target == CloseTarget::Window) closeTarget_ = target;
            return;
        }
        closeTarget_ = target;
        homePending_ = false;
        diagnoseAfterStop_ = false;
        Stop();
    }

    void CompleteClose(CloseTarget target)
    {
        port_.Close();
        ClearPending();
        reader_.Clear();
        closeTarget_ = CloseTarget::None;
        sequenceRunning_ = false;
        sequenceWaiting_ = false;
        homePending_ = false;
        diagnoseAfterStop_ = false;
        confirmed_ = false;
        hasPosition_ = false;
        position_ = 0;
        currentStation_ = -1;
        dial_->Mark();
        station_->setText(QStringLiteral("当前工位：--"));
        angle_->setText(QStringLiteral("角度：--"));
        Finish(QStringLiteral("串口已关闭。"));
        if (target == CloseTarget::Window)
            QTimer::singleShot(0, this, [this] { close(); });
    }

    void Tick()
    {
        if (!port_.IsOpen()) return;
        port_.ReadAvailable(reader_);
        lk::Frame frame{};
        while (reader_.Next(frame))
        {
            Log(QStringLiteral("RX  ") + Hex(lk::Encode(frame.command, frame.motorId, frame.payload)), false);
            if (!hasPending_ || frame.motorId != 1 || frame.command != pending_.command
                || frame.payload.size() != pending_.length) continue;
            auto callback = std::move(pending_.callback);
            ClearPending();
            callback(frame);
            break;
        }
        const auto now = clock_.elapsed();
        if (hasPending_ && now >= pending_.deadline)
            throw QStringLiteral("等待电机应答超时（0x%1）。")
                .arg(pending_.command, 2, 16, QLatin1Char('0')).toStdWString();
        if (hasPending_ || !port_.IsOpen()) return;
        if (operation_ == Operation::Jogging && now >= move_.deadline)
        {
            Request(lk::ReadSingleAngle, 4, {}, [this](const lk::Frame& frame) {
                const auto value = lk::DecodeSingleAngle(frame.payload);
                UpdatePosition(value);
                Finish(QStringLiteral("点动位置已读取：%1°。").arg(value / 100.0, 0, 'f', 2));
            });
            pending_.deadline = clock_.elapsed() + 300;
        }
        else if (operation_ == Operation::Moving)
        {
            if (move_.timed && now >= move_.deadline)
            {
                hasPosition_ = false;
                position_ = 0;
                angle_->setText(QStringLiteral("角度：--"));
                currentStation_ = -1;
                dial_->Mark(move_.station);
                station_->setText(QStringLiteral("目标工位：%1（按时间推进）").arg(move_.station + 1));
                CompleteMove(QStringLiteral("定时等待结束，开始停留。"));
            }
            else if (now >= move_.deadline)
            {
                const auto difference = ratio_->value() == 1.0
                    ? turret::TravelTo(static_cast<int>(position_), static_cast<int>(move_.target), false)
                    : move_.target - position_;
                throw QStringLiteral("定位超时：目标 %1°，末次位置 %2°，轮盘偏差 %3°，容差 ±%4°，连续命中 %5/2。将自动停止并读取诊断。")
                    .arg(move_.target / 100.0, 0, 'f', 2).arg(position_ / 100.0, 0, 'f', 2)
                    .arg(difference / (100.0 * ratio_->value()), 0, 'f', 2)
                    .arg(tolerance_->value(), 0, 'f', 2).arg(move_.stableSamples).toStdWString();
            }
            else if (!move_.timed && now >= nextPoll_)
                PollMotion();
        }
        else if (operation_ == Operation::Idle && sequenceRunning_ && sequenceWaiting_ && now >= sequenceDue_)
            AdvanceSequence();
    }

    void Finish(const QString& message)
    {
        operation_ = Operation::Idle;
        Log(message);
        UpdateControls();
    }

    void UpdateControls()
    {
        const bool opened = port_.IsOpen();
        const bool idle = operation_ == Operation::Idle && !hasPending_;
        const bool editable = idle && !sequenceRunning_;
        com_->setEnabled(!opened);
        baud_->setEnabled(!opened);
        refresh_->setEnabled(!opened);
        open_->setText(closeTarget_ != CloseTarget::None ? QStringLiteral("正在关闭…")
            : opened ? QStringLiteral("关闭串口") : QStringLiteral("打开串口"));
        open_->setEnabled(closeTarget_ == CloseTarget::None);
        connectionState_->setText(opened
            ? confirmed_ ? QStringLiteral("电机已应答") : QStringLiteral("串口已打开") : QStringLiteral("未连接"));
        for (auto* button : dial_->buttons) button->setEnabled(opened && editable);
        for (auto* button : {origin_, jogLeft_, jogRight_, run_, diagnose_})
            button->setEnabled(opened && editable);
        debug_->setEnabled(editable);
        stop_->setEnabled(opened && operation_ != Operation::Stopping);
        home_->setEnabled(opened && operation_ != Operation::Stopping);
        const std::array<QWidget*, 8> inputs{speed_, tolerance_, ratio_, mode_,
            jogStep_, sequenceText_, loop_, moveMargin_};
        for (auto* input : inputs) input->setEnabled(editable);
        forward_->setEnabled(editable && (mode_->currentIndex() == 0 || sequenceUsesTiming_));
    }

    void Log(const QString& message, bool visible = true)
    {
        const QString line = QDateTime::currentDateTime().toString(QStringLiteral("HH:mm:ss.zzz"))
            + QStringLiteral("  ") + message;
        if (logFile_.isOpen())
        {
            const auto data = (line + QLatin1Char('\n')).toUtf8();
            if (logFile_.write(data) != data.size() || !logFile_.flush())
            {
                log_->appendPlainText(QStringLiteral("日志文件写入失败：%1").arg(logFile_.errorString()));
                logFile_.close();
            }
        }
        if (visible) log_->appendPlainText(line);
    }

    lk::Port port_;
    lk::FrameReader reader_;
    bool hasPending_ = false;
    Pending pending_{};
    Operation operation_ = Operation::Idle;
    CloseTarget closeTarget_ = CloseTarget::None;
    MoveState move_;
    bool confirmed_ = false;
    bool homePending_ = false;
    bool diagnoseAfterStop_ = false;
    bool sequenceRunning_ = false;
    bool sequenceWaiting_ = false;
    bool sequenceUsesTiming_ = true;
    bool releaseAfterArrival_ = false;
    std::int64_t offset_ = 0;
    bool hasPosition_ = false;
    std::int64_t position_ = 0;
    int currentStation_ = -1;
    QVector<turret::SequenceStep> steps_;
    int sequenceIndex_ = 0;
    int sequenceRound_ = 0;
    qint64 sequenceDue_ = 0;
    qint64 nextPoll_ = 0;
    QElapsedTimer clock_;
    QTimer timer_;
    QFile logFile_;
    QString configPath_;
    StationDial* dial_;
    QComboBox* com_;
    QComboBox* baud_;
    QComboBox* mode_;
    QDoubleSpinBox* speed_;
    QDoubleSpinBox* tolerance_;
    QDoubleSpinBox* ratio_;
    QDoubleSpinBox* jogStep_;
    QSpinBox* moveMargin_;
    QCheckBox* loop_;
    QCheckBox* forward_;
    QLineEdit* sequenceText_;
    QPushButton* refresh_;
    QPushButton* open_;
    QPushButton* origin_;
    QPushButton* jogLeft_;
    QPushButton* jogRight_;
    QPushButton* debug_;
    QPushButton* diagnose_;
    QPushButton* run_;
    QPushButton* stop_;
    QPushButton* home_;
    QLabel* connectionState_;
    QLabel* angle_;
    QLabel* station_;
    QPlainTextEdit* log_;
};
}

int main(int argc, char* argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif
    QApplication app(argc, argv);
    QApplication::setApplicationName(QStringLiteral("MotorControl"));
    QApplication::setApplicationDisplayName(QStringLiteral("Rotary control"));
    QApplication::setWindowIcon(QIcon(QStringLiteral(":/icons/MotorControl.png")));
    MotorControlWindow window;
    window.show();
    return app.exec();
}
