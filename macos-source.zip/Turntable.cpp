#include "Turntable.h"
#include "Rs485.h"
#include <cmath>

namespace turret
{
int Normalize(int angle)
{
    return (angle % lk::FullTurn + lk::FullTurn) % lk::FullTurn;
}
int AngleTo(int origin, int station)
{
    return Normalize(origin + station * 6000);
}
int TravelTo(int current, int target, bool forwardOnly)
{
    int travel = Normalize(target - current);
    if (!forwardOnly && travel > lk::FullTurn / 2) travel -= lk::FullTurn;
    return travel;
}
std::int64_t GearedTarget(std::int64_t origin, std::int64_t current, int station, double ratio)
{
    const auto span = std::llround(lk::FullTurn * ratio);
    const auto phase = origin + std::llround(station * 6000.0 * ratio);
    const auto turn = std::llround(static_cast<double>(current - phase) / span);
    return phase + turn * span;
}
QVector<SequenceStep> ParseSequence(QString text)
{
    text.replace(QChar(0xff0c), QLatin1Char(','));
    text.remove(QLatin1Char(' '));
    QVector<SequenceStep> steps;
    for (const auto& item : text.split(QLatin1Char(',')))
    {
        if (item.isEmpty()) continue;
        const auto pair = item.split(QLatin1Char(':'));
        bool stationOk = false;
        bool dwellOk = true;
        const int station = pair[0].toInt(&stationOk);
        const int dwell = pair.size() == 2 ? pair[1].toInt(&dwellOk) : 500;
        if (pair.size() > 2 || !stationOk || station < 1 || station > 6
            || !dwellOk || dwell < 0 || dwell > 3600000)
            throw std::wstring(L"序列格式错误，请使用 1:500, 3:500, 5:500，停留时间单位为毫秒。");
        steps.push_back({station - 1, dwell});
    }
    if (steps.isEmpty()) throw std::wstring(L"请至少输入一个工位。");
    return steps;
}
}
