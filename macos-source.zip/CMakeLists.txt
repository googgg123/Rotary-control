cmake_minimum_required(VERSION 3.16)
project(MotorControl VERSION 2.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 14)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_AUTORCC ON)
find_package(QT NAMES Qt6 Qt5 REQUIRED COMPONENTS Widgets SerialPort)
find_package(Qt${QT_VERSION_MAJOR} REQUIRED COMPONENTS Widgets SerialPort)

add_executable(MotorControl WIN32 MACOSX_BUNDLE
    MotorControl.cpp
    Turntable.cpp Turntable.h
    Rs485.cpp Rs485.h
    MotorControl.qrc
)
set_target_properties(MotorControl PROPERTIES
    OUTPUT_NAME "Rotary control"
    MACOSX_BUNDLE_BUNDLE_NAME "Rotary control"
)
target_link_libraries(MotorControl PRIVATE
    Qt${QT_VERSION_MAJOR}::Widgets
    Qt${QT_VERSION_MAJOR}::SerialPort
)
if(QT_VERSION_MAJOR EQUAL 6)
    # Qt 6 itself requires C++17, even though this application's code uses C++14.
    target_compile_features(MotorControl PRIVATE cxx_std_17)
endif()
if(MSVC)
    target_compile_options(MotorControl PRIVATE /utf-8)
endif()
if(WIN32)
    enable_language(RC)
    target_sources(MotorControl PRIVATE MotorControl.rc)
endif()
if(APPLE)
    target_sources(MotorControl PRIVATE assets/MotorControl.icns)
    set_source_files_properties(assets/MotorControl.icns
        PROPERTIES MACOSX_PACKAGE_LOCATION Resources)
    set_target_properties(MotorControl PROPERTIES
        MACOSX_BUNDLE_ICON_FILE MotorControl.icns
        MACOSX_BUNDLE_GUI_IDENTIFIER com.opt.motorcontrol
        MACOSX_BUNDLE_BUNDLE_VERSION ${PROJECT_VERSION}
        MACOSX_BUNDLE_SHORT_VERSION_STRING ${PROJECT_VERSION}
    )
endif()
