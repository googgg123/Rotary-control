#pragma once
#include <QString>
#include <QVector>
#include <cstdint>

namespace turret
{
struct SequenceStep
{
    int station;
    int dwellMs;
};
int Normalize(int angle);
int AngleTo(int origin, int station);
int TravelTo(int current, int target, bool forwardOnly);
std::int64_t GearedTarget(std::int64_t origin, std::int64_t current, int station, double ratio);
QVector<SequenceStep> ParseSequence(QString text);
}
