#include "Rs485.h"

#include <algorithm>
#include <cstring>
#include <numeric>
#include <QElapsedTimer>

namespace lk
{
namespace
{
constexpr Byte FrameHead = 0x3E;
constexpr std::size_t HeaderSize = 5;

std::uint32_t ParseNumber(const std::wstring& text, unsigned decimals,
                          std::uint32_t maximum, const wchar_t* error)
{
    const auto first = text.find_first_not_of(L" \t");
    if (first == std::wstring::npos) throw std::wstring(error);
    const auto last = text.find_last_not_of(L" \t");
    std::uint64_t value = 0;
    bool point = false;
    bool hasDigit = false;
    unsigned fraction = 0;
    for (std::size_t i = first; i <= last; ++i)
    {
        const wchar_t ch = text[i];
        if (ch == L'.' && decimals && !point)
        {
            point = true;
            continue;
        }
        if (ch < L'0' || ch > L'9' || (point && ++fraction > decimals))
            throw std::wstring(error);
        hasDigit = true;
        value = value * 10 + (ch - L'0');
        if (value > maximum) throw std::wstring(error);
    }
    for (; fraction < decimals; ++fraction) value *= 10;
    if (!hasDigit || !value || value > maximum) throw std::wstring(error);
    return static_cast<std::uint32_t>(value);
}

void AppendU32(Bytes& payload, std::uint32_t value)
{
    for (unsigned shift = 0; shift < 32; shift += 8)
        payload.push_back(static_cast<Byte>(value >> shift));
}

Byte Checksum(const Byte* first, std::size_t n)
{
    return static_cast<Byte>(std::accumulate(first, first + n, 0u));
}

std::wstring SerialError(const wchar_t* operation, const QSerialPort& serial)
{
    return std::wstring(operation) + L"失败：" + serial.errorString().toStdWString();
}
}

Motion MakeMotion(const std::wstring& stepAngle, const std::wstring& stepCount,
                  bool reverse, const std::wstring* speed)
{
    const auto angle = ParseNumber(stepAngle, 2, FullTurn, L"每步角度请输入 0.01～360.00，最多两位小数。");
    const auto count = ParseNumber(stepCount, 0, FullTurn, L"步数请输入 1～36000 的整数。");
    const auto total = angle * count;
    if (total > FullTurn) throw std::wstring(L"每步角度 × 本次步数不能超过 360°。");

    Motion motion{static_cast<std::int32_t>(total)};
    if (reverse) motion.angle = -motion.angle;
    if (speed)
    {
        // The range follows the vendor's RS485 example, with zero excluded.
        motion.limit = ParseNumber(*speed, 2, 600000, L"速度上限请输入 0.01～6000.00 °/秒，最多两位小数。");
        motion.hasLimit = true;
    }
    return motion;
}

Bytes Motion::payload() const
{
    Bytes bytes;
    AppendU32(bytes, static_cast<std::uint32_t>(angle));
    if (hasLimit) AppendU32(bytes, limit);
    return bytes;
}

Bytes SingleAnglePayload(std::int32_t target, bool reverse, std::uint32_t speedLimit)
{
    if (target < 0 || target >= FullTurn)
        throw std::wstring(L"单圈目标角度必须在 0°～359.99° 之间。");
    if (speedLimit == 0 || speedLimit > 600000)
        throw std::wstring(L"速度上限必须在 0.01～6000.00 °/秒之间。");

    // Vendor 0xA6 layout: direction, 24-bit angle, 32-bit speed, little-endian.
    Bytes bytes{static_cast<Byte>(reverse), static_cast<Byte>(target),
                static_cast<Byte>(target >> 8), static_cast<Byte>(target >> 16)};
    AppendU32(bytes, speedLimit);
    return bytes;
}

Bytes Encode(Byte command, Byte motorId, const Bytes& payload)
{
    Bytes frame{FrameHead, command, motorId, static_cast<Byte>(payload.size())};
    frame.push_back(Checksum(frame.data(), frame.size()));
    if (!payload.empty())
    {
        frame.insert(frame.end(), payload.begin(), payload.end());
        frame.push_back(Checksum(payload.data(), payload.size()));
    }
    return frame;
}

std::int64_t DecodeAngle(const Bytes& payload)
{
    std::uint64_t bits = 0;
    for (unsigned i = 0; i < 8; ++i)
        bits |= static_cast<std::uint64_t>(payload.at(i)) << (8 * i);
    std::int64_t angle = 0;
    std::memcpy(&angle, &bits, sizeof(angle));
    return angle;
}

std::int32_t DecodeSingleAngle(const Bytes& payload)
{
    std::uint32_t value = 0;
    for (unsigned i = 0; i < 4; ++i)
        value |= static_cast<std::uint32_t>(payload.at(i)) << (8 * i);
    if (value > FullTurn)
        throw std::wstring(L"驱动器返回了无效的单圈位置。");
    return static_cast<std::int32_t>(value % FullTurn);
}

int DecodeSpeed(const Bytes& payload)
{
    const int raw = payload.at(3) | (payload.at(4) << 8);
    return raw >= 0x8000 ? raw - 0x10000 : raw;
}

void FrameReader::Append(const Byte* data, std::size_t size)
{
    buffer_.insert(buffer_.end(), data, data + size);
}

bool FrameReader::Next(Frame& frame)
{
    while (buffer_.size() >= HeaderSize)
    {
        const auto length = buffer_[3];
        const auto size = HeaderSize + length + (length ? 1 : 0);
        if (buffer_[0] == FrameHead && buffer_[2] >= 1 && buffer_[2] <= 32
            && Checksum(buffer_.data(), HeaderSize - 1) == buffer_[4])
        {
            if (buffer_.size() < size) return false;
            const auto data = buffer_.data() + HeaderSize;
            if (!length || Checksum(data, length) == data[length])
            {
                frame = Frame{buffer_[1], buffer_[2], Bytes(data, data + length)};
                buffer_.erase(buffer_.begin(), buffer_.begin() + size);
                return true;
            }
        }
        buffer_.erase(buffer_.begin());
    }
    return false;
}

void Port::Open(const std::wstring& name, std::uint32_t baud)
{
    Close();
    serial_.setPortName(QString::fromStdWString(name));
    if (!serial_.open(QIODevice::ReadWrite)) throw SerialError(L"打开串口", serial_);
    try
    {
        if (!serial_.setBaudRate(static_cast<qint32>(baud))
            || !serial_.setDataBits(QSerialPort::Data8)
            || !serial_.setParity(QSerialPort::NoParity)
            || !serial_.setStopBits(QSerialPort::OneStop)
            || !serial_.setFlowControl(QSerialPort::NoFlowControl))
            throw SerialError(L"配置串口", serial_);
        ClearInput();
    }
    catch (...)
    {
        Close();
        throw;
    }
}

void Port::Close()
{
    serial_.close();
}

void Port::Write(const Bytes& frame)
{
    if (serial_.write(reinterpret_cast<const char*>(frame.data()), static_cast<qint64>(frame.size()))
        != static_cast<qint64>(frame.size()))
        throw SerialError(L"发送报文", serial_);
    QElapsedTimer timer;
    timer.start();
    while (serial_.bytesToWrite() > 0)
    {
        const int remaining = 300 - static_cast<int>(timer.elapsed());
        if (remaining <= 0 || !serial_.waitForBytesWritten(remaining))
            throw SerialError(L"发送报文", serial_);
    }
}

void Port::ReadAvailable(FrameReader& reader)
{
    if (serial_.error() == QSerialPort::ResourceError || serial_.error() == QSerialPort::DeviceNotFoundError)
    {
        const auto message = SerialError(L"接收报文", serial_);
        Close();
        throw message;
    }
    const auto data = serial_.readAll();
    reader.Append(reinterpret_cast<const Byte*>(data.constData()), static_cast<std::size_t>(data.size()));
}

void Port::ClearInput()
{
    if (!serial_.clear(QSerialPort::Input)) throw SerialError(L"清理串口接收缓存", serial_);
}
}
