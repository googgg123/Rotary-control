#pragma once

#include <QSerialPort>

#include <cstdint>
#include <string>
#include <vector>

namespace lk
{
using Byte = std::uint8_t;
using Bytes = std::vector<Byte>;

constexpr Byte Stop = 0x81;
constexpr Byte Connect = 0x10;
constexpr Byte MotorRun = 0x88;
constexpr Byte MotorOff = 0x80;
constexpr Byte ClearLoops = 0x93;
constexpr Byte ReadSettings = 0x14;
constexpr Byte ReadAngle = 0x92;
constexpr Byte ReadSingleAngle = 0x94;
constexpr Byte ReadFault = 0x9A;
constexpr Byte ReadSpeed = 0x9C;
constexpr Byte MoveSingleLimited = 0xA6;
constexpr Byte Move = 0xA7;
constexpr Byte MoveLimited = 0xA8;
constexpr std::int32_t FullTurn = 36000;

struct Frame
{
    Byte command;
    Byte motorId;
    Bytes payload;
};

struct Motion
{
    std::int32_t angle = 0;   // Signed, in 0.01 degrees.
    bool hasLimit = false;
    std::uint32_t limit = 0;  // In 0.01 degrees per second.

    explicit Motion(std::int32_t angleValue) : angle(angleValue) {}
    Motion(std::int32_t angleValue, std::uint32_t speedLimit)
        : angle(angleValue), hasLimit(true), limit(speedLimit) {}

    Byte command() const { return hasLimit ? MoveLimited : Move; }
    Bytes payload() const;
};

Motion MakeMotion(const std::wstring& stepAngle, const std::wstring& stepCount,
                  bool reverse, const std::wstring* speed = nullptr);
Bytes Encode(Byte command, Byte motorId, const Bytes& payload = {});
Bytes SingleAnglePayload(std::int32_t target, bool reverse, std::uint32_t speedLimit);
std::int64_t DecodeAngle(const Bytes& payload);
std::int32_t DecodeSingleAngle(const Bytes& payload);
int DecodeSpeed(const Bytes& payload);

class FrameReader
{
public:
    void Append(const Byte* data, std::size_t size);
    bool Next(Frame& frame);
    void Clear() { buffer_.clear(); }

private:
    Bytes buffer_;
};

class Port
{
public:
    Port() = default;
    ~Port() { Close(); }
    Port(const Port&) = delete;
    Port& operator=(const Port&) = delete;

    void Open(const std::wstring& name, std::uint32_t baud);
    void Close();
    bool IsOpen() const { return serial_.isOpen(); }
    void Write(const Bytes& frame);
    void ReadAvailable(FrameReader& reader);
    void ClearInput();

private:
    QSerialPort serial_;
};
}
